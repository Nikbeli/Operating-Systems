﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab6
{
    internal class BankersAlgorithm
    {
        static int n = 5;  // количество процессов
        static int m = 3;  // количество ресурсов
        int[,] need = new int[n, m];   // матрица запросов
        int[,] max;    // матрица всех ресурсов
        int[,] allocation;  // матрица распределения
        int[] available;    // массив доступных ресурсов
        int[] safeSequence = new int[n];   // порядок выполнения безопасных процессов

        public void initializeValues()
        {
            allocation = new int[,] {
                { 0, 1, 0 }, //P0
                { 2, 0, 0 }, //P1
                { 3, 0, 2 }, //P2
                { 2, 1, 1 }, //P3
                { 0, 0, 2 }  //P4
        };

            max = new int[,] {
                { 7, 5, 3 }, //P0
                { 3, 2, 2 }, //P1
                { 11, 0, 2 }, //P2
                { 2, 2, 2 }, //P3
                { 4, 3, 3 }  //P4
        };

            available = new int[] { 10, 10, 1 };
            
            Console.WriteLine("Матрица распределения");
            for (int i = 0; i < n; i++)
            {
                for (int k = 0; k < m; k++)
                {
                    Console.Write(allocation[i,k] + "\t");
                }
                Console.WriteLine();
            }
            Console.WriteLine("Матрица всех ресурсов");
            for (int i = 0; i < n; i++)
            {
                for (int k = 0; k < m; k++)
                {
                    Console.Write(max[i, k] + "\t");
                }
                Console.WriteLine();
            }
            Console.WriteLine("Массив доступных ресурсов");

            for (int k = 0; k < m; k++)
            {
                Console.Write(available[k] + "\t");
            }
            Console.WriteLine();

        }


        // Проверка на безопасность
        public void isSafe()
        {
            int count = 0; // количество безопасных процессов

            // состояние системы
            // массив (не)безопасности процессов
            bool[] visited = new bool[n];

            //сначала все небезопасны (т.к. пока не проверены)
            for (int i = 0; i < n; i++)
            {
                visited[i] = false;
            }

            // массив обработки (изначально равен массиву доступных ресурсов)
            int[] work = available;

            while (count < n)
            {
                bool flag = false;
                Console.WriteLine("Обработка");
                for (int i = 0; i < n; i++)
                {
                    if (visited[i] == false)
                    {
                        int j;
                        for (j = 0; j < m; j++)
                        {
                            if (need[i,j] > work[j])
                                break;
                        }
                        if (j == m)
                        {
                            safeSequence[count++] = i;
                            visited[i] = true;
                            flag = true;

                            for (j = 0; j < m; j++)
                            {
                                work[j] = work[j] + allocation[i,j]; //обновляем work
                                Console.Write(work[j] + "\t");
                            }
                            Console.WriteLine("Добавлен P" + (i+1));
                        }
                    }
                }
                if (flag == false)
                {
                    break;
                }
            }
            if (count < n)
            {
                Console.WriteLine("===================================================");
                Console.WriteLine("!!! СИСТЕМА НЕБЕЗОПАСНА !!!");
                Console.WriteLine("Количество забракованных процессов: " + (n - count));
                Console.WriteLine("===================================================");
            }
            else
            {
                //System.out.println("The given System is Safe");
                Console.WriteLine("===================================================");
                Console.WriteLine("!!! СИСТЕМА БЕЗОПАСНА !!!");
                Console.WriteLine("Безопасная последовательность действий:");

                for (int i = 0; i < n; i++)
                {
                    Console.WriteLine("P" + ((safeSequence[i])+1));
                    if (i != n - 1)
                        Console.WriteLine(" -> ");
                }

                Console.WriteLine("\n===================================================");
            }
        }

        // Вычисление матрицы запросов
        // (матрица доступных ресурсов - матрица распределения)
        public void calculateNeed()
        {
            Console.WriteLine("Матрицы запросов");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    need[i,j] = max[i,j] - allocation[i,j];
                    Console.Write(need[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }
    }
}
