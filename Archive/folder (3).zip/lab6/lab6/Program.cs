﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankersAlgorithm lab6 = new BankersAlgorithm();

            lab6.initializeValues();
            //Calculate the Need Matrix
            lab6.calculateNeed();

            // Check whether system is in safe state or not
            lab6.isSafe();

            Console.ReadLine();
        }
    }
}
