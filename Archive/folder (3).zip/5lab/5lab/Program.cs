﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5lab
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Core core = new Core();
            core.createProcess();
            core.printAllProcess();
            core.planingWithBlock();
            core.planingWithoutBlock();
            Console.ReadLine();
        }
    }
}
