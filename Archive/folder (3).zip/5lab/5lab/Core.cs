﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5lab
{
    internal class Core
    {
        Random random = new Random();

        public Queue<Process> queueWithBlock = new Queue<Process>();
        public Queue<Process> queueWithoutBlock = new Queue<Process>();

        public void createProcess()
        {
            for (int i = 1; i <= random.Next(0, 11) + 1; i++)
            {
                bool workWithDevices =  Convert.ToBoolean(random.Next(0,2));
                int timeBeforeWorkWithDevices = random.Next(1001) + 500;
                int timeWorkWithDevices = random.Next(401) + 100;
                int timeAfterWorkWithDevices = random.Next(1001) + 500;
                Process processToQueueWithBlock = new Process(i, workWithDevices, timeBeforeWorkWithDevices, timeWorkWithDevices, timeAfterWorkWithDevices);
                queueWithBlock.Enqueue(processToQueueWithBlock);
                Process processToQueueWithoutBlock = new Process(i, workWithDevices, timeBeforeWorkWithDevices, timeWorkWithDevices, timeAfterWorkWithDevices);
                queueWithoutBlock.Enqueue(processToQueueWithoutBlock);
            }
        }

        public void printAllProcess()
        {
            List<Process> listForPrint = new List<Process>(queueWithBlock);
            Console.WriteLine("Мы имеем " + listForPrint.Count + " процессов:");
            for (int i = 0; i < listForPrint.Count(); i++)
            {
                Console.WriteLine("Процесс " + listForPrint.ElementAt(i).getID() + " требует " + listForPrint.ElementAt(i).getTotalTime() + " такт(а)(ов) на выполнение" +
                        " - данный процесс " + listForPrint.ElementAt(i).getWorkWithDevices() + listForPrint.ElementAt(i).getTimeWorkWithDevicesToPrint());
            }
            Console.WriteLine();
        }

        public void planingWithBlock()
        {
            int totalWorkTime = 0;
            Console.WriteLine("\n====================================================");
            Console.WriteLine("Начинает работать планировщик с блокировками \n");
            Console.WriteLine("=====================================================\n");
            Process process = queueWithBlock.Dequeue();
            while (queueWithBlock.Count != 0)
            {
                String result = process.executeProcessWithBlock();
                Console.WriteLine(result + "\n");
                if (result.Contains("из-за"))
                {
                    totalWorkTime += process.getTimeWorkWithDevices();
                    Process newProcess = queueWithBlock.Peek();
                    result = newProcess.executeProcessWithBreaking(process.getTimeWorkWithDevices());
                    process.setTimeWorkWithDevices();
                    Console.WriteLine(result + "\n");
                    result = process.continueExecuteProcessWithBlock();
                    Console.WriteLine(result + "\n");
                }
                if (result.Contains("приостановлен"))
                {
                    queueWithBlock.Enqueue(process);
                }
                totalWorkTime += process.getWorkTime();
                process = queueWithBlock.Dequeue();
            }
            Console.WriteLine("Общее время затраченное на выполнение процессов " + totalWorkTime + " такт(а)(ов) \n");
        }

        public void planingWithoutBlock()
        {
            int totalWorkTime = 0;
            Console.WriteLine("\n====================================================");
            Console.WriteLine("Начинает работать планировщик без блокировок \n");
            Console.WriteLine("=====================================================\n");
            Process process = queueWithoutBlock.Dequeue();
            while (queueWithoutBlock.Count != 0)
            {
                String result = process.executeProcessWithoutBlock();
                Console.WriteLine(result + "\n");
                if (result.Contains("приостановлен"))
                {
                    queueWithoutBlock.Enqueue(process);
                }
                totalWorkTime += process.getWorkTime();
                process = queueWithoutBlock.Dequeue();
            }
            Console.WriteLine("Общее время затраченное на выполнение процессов " + totalWorkTime + " такт(а)(ов) \n");
        }
    }
}
