﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    internal class Thread
    {
        public String name;
        public int time;

        public Thread(String name, int time)
        {
            this.name = name;
            this.time = time;
        }
    }
}
