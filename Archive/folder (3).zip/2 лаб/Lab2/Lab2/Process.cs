﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    internal class Process
    {
        public String name;
        public int max_time;
        private Thread[] threads;
        private int head = 0;
        public int allTime = 0;

        public Process(String name, int max_time, int number)
        {
            this.name = name;
            this.max_time = max_time;
            this.threads = new Thread[number];
        }

        public void AddThread(Thread th)
        {
            this.threads[this.head++] = th;
        }

        public void Print()
        {
            for (int i = 0; i < this.head; ++i)
            {
                Console.WriteLine("    " + (i + 1) + ") " + this.threads[i].name + " = " + this.threads[i].time + " ms ");
            }

        }
        public void PrintProcess()
        {

            for (int i = 0; i < this.head; ++i)
            {
                Console.Write("    " + (i + 1) + ") " + this.threads[i].name + " = " + this.threads[i].time + " ms \t");
                for (int k = 0; k < ((allTime/5)); ++k)
                { Console.Write(" "); }
                //Console.Write("Start");

                
                for (int k = 0; k < this.threads[i].time; k += 5)
                { Console.Write("-"); }
                allTime += this.threads[i].time;
                //Console.Write("End");
                Console.WriteLine();
            }

        }
    }
}
