﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    internal class Scheduler
    {
        private Process[] processes;
        private int head = 0;

        public Scheduler(int number)
        {
            this.processes = new Process[number];
        }

        public void AddProc(Process proc)
        {
            this.processes[this.head++] = proc;
        }

        //Выбор следующим самого короткого процесса
        public void Sorting()
        {
            if (this.head != 0 && this.head != 1)
            {
                for (int i = 0; i < this.head - 1; ++i)
                {
                    for (int j = i + 1; j < this.head; ++j)
                    {
                        if (this.processes[i].max_time > this.processes[j].max_time)
                        {
                            Process tmp = this.processes[i];
                            this.processes[i] = this.processes[j];
                            this.processes[j] = tmp;
                        }
                    }
                }

            }
        }

        public void Print()
        {
            for (int i = 0; i < this.head; ++i)
            {
                Console.WriteLine("[" + (i + 1) + "]" + this.processes[i].name + " = " + this.processes[i].max_time + " ms");
                this.processes[i].Print();

            }

        }

        public void PrintGraphic()
        {
            int probel = 0;
            for (int i = 0; i < this.head; ++i)
            {
                Console.Write("[" + (i + 1) + "]" + this.processes[i].name + " = " + this.processes[i].max_time + " ms \t\t");
                for (int k = 0; k < probel; ++k)
                { Console.Write(" "); }
                Console.Write("Start");

                for (int k = 0; k < this.processes[i].max_time; k += 5)
                { Console.Write("-"); probel++; }
                Console.Write("End");
                Console.WriteLine();
                this.processes[i].PrintProcess();

            }
        }
    }
}
