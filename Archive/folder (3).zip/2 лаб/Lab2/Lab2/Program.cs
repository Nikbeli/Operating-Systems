﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Thread th1 = new Thread("Thread N1", 90);
            Thread th2 = new Thread("Thread N2", 10);
            Thread th3 = new Thread("Thread N3", 60);
            Thread th4 = new Thread("Thread N3", 60);

            Process proc1 = new Process("Process N1", th4.time + th3.time + th2.time + th1.time, 4);
            proc1.AddThread(th1);
            proc1.AddThread(th2);
            proc1.AddThread(th3);
            proc1.AddThread(th4);

            th1 = new Thread("Thread N1", 10);
            th2 = new Thread("Thread N2", 20);

            Process proc2 = new Process("Process N2", th2.time + th1.time, 4);
            proc2.AddThread(th1);
            proc2.AddThread(th2);

            th1 = new Thread("Thread N1", 60);

            Process proc3 = new Process("Process N3", th1.time, 4);
            proc3.AddThread(th1);

            proc1.allTime = 115;
            proc2.allTime = 25;
            proc3.allTime = 55; 


            Scheduler Lab = new Scheduler(3);
            Lab.AddProc(proc1);
            Lab.AddProc(proc2);
            Lab.AddProc(proc3);
            Lab.Sorting();
            Lab.Print();

            Console.WriteLine("------Graphic------");
            Lab.PrintGraphic();


            Console.ReadLine();
        }
    }
}
